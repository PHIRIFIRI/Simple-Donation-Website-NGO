<?php
$servername = "localhost";
$username = "root"; // replace with your database username
$password = ""; // replace with your database password
$dbname = "EnquiriesDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the form data
$donator_name = $_POST['donator_name'];
$last_name = $_POST['last_name'];
$donator_email = $_POST['donator_email'];
$phone = $_POST['phone'];
$type_of_donation = $_POST['type_of_donation'];
$donation_day = $_POST['donation_day'];
$special_comments = $_POST['special_comments'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO Enquiries (donator_name, last_name, donator_email, phone, type_of_donation, donation_day, special_comments) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssss", $donator_name, $last_name, $donator_email, $phone, $type_of_donation, $donation_day, $special_comments);

// Execute the statement
if ($stmt->execute()) {
    echo "New record created successfully";
} else {
    echo "Error: " . $stmt->error;
}

// Close the connection
$stmt->close();
$conn->close();
?>
